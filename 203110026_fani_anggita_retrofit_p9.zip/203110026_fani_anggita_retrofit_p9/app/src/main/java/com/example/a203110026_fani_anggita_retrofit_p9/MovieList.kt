package com.example.a203110026_fani_anggita_retrofit_p9


import com.google.gson.annotations.SerializedName

data class MovieList(@SerializedName("Search") val List : List<Movie>)